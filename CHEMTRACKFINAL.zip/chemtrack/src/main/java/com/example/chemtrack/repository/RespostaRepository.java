package com.example.chemtrack.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.chemtrack.model.Resposta;

public interface RespostaRepository extends JpaRepository<Resposta, Long> {
}

