package com.example.chemtrack.repository;





import org.springframework.data.jpa.repository.JpaRepository;
import com.example.chemtrack.model.Insignia;

public interface InsigniaRepository extends JpaRepository<Insignia, Long> {

	
}

