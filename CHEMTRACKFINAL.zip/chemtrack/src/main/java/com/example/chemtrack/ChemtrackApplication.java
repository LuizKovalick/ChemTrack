package com.example.chemtrack;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChemtrackApplication {

	public static void main(String[] args) {
		SpringApplication.run(ChemtrackApplication.class, args);
	}

}
